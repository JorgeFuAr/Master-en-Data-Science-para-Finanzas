library(shiny)


ui <- shinyUI(
  sidebarLayout(
    sidebarPanel(
      actionButton("norm", "Muestra normal"), # Creamos botón para posteriormente hacer la distribución normal
      actionButton("unif", "Muestra uniforme"), # Creamos botón para posteriormente hacer la distribución uniforme
      sliderInput("n", "Tamaño muestral", min = 0, max = 2000, value = 1000)
      # Con el slider, el usuario podrá elegir el tamaño muestral que quiera entre 0 y 2000 observaciones.
    ),
    mainPanel(
      plotOutput("plot") # Gráfica para posteriormente conseguir histogramas
    )
  )
)

server <- function(input, output) {

  # Con este primer observeEvent, queremos hacer que únicamente cuando pulsemos el boton de "Muestra normal"
  # se visualice un histograma de tamaño muestral n (el elegido por el usuario) en cuyo titulo se muestre el número
  # observaciones escogidas. Si se cambia el tamaño muestral, no se cambiará el histograma hasta que el usuario
  # vuelva al pulsar el botón.
  observeEvent(input$norm, {
      output$plot <- renderPlot({
        hist(rnorm(isolate(input$n)), 
             main = paste0("Histograma distribución normal de ", isolate(input$n), " observaciones"))
      })
    })
  
  # Realiza el mismo proceso que anteriormente pero pulsando el botón "Muestra uniforme":
  # Con este segundo observeEvent, queremos hacer que únicamente cuando pulsemos el boton de "Muestra uniforme"
  # se visualice un histograma de tamaño muestral n (el elegido por el usuario) en cuyo titulo se muestre el número
  # observaciones escogidas. Si se cambia el tamaño muestral, no se cambiará el histograma hasta que el usuario
  # vuelva al pulsar el botón.
  observeEvent(input$unif, {
    output$plot <- renderPlot({
      hist(runif(isolate(input$n)), 
           main = paste0("Histograma distribución uniforme de ", isolate(input$n), " observaciones"))
    })
  })
}

shinyApp(ui = ui, server = server)