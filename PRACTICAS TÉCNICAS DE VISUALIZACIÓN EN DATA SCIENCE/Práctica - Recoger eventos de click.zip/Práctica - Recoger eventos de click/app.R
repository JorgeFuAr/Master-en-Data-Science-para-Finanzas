library(shiny)
library(ggplot2)

# Define UI for application that draws a histogram
ui <- shinyUI(
  fluidPage(
    titlePanel("Recoger eventos de click"),
    plotOutput("Gráfica", hover = "clickGráfica", click = "clickGráfica1", dblclick = "clickGráfica2"), #dblclick saca la informacion con doble click, click solo con uno solo y overclick te da la informacion al pasarlo por encima
    tabsetPanel(
      tabPanel("Hover", tableOutput("hover")),
      tabPanel("Click", tableOutput("click")),
      tabPanel("Doble Click", tableOutput("dblclick"))
  ))
)
   
# Define server logic required to draw a histogram
server <- shinyServer(function(input, output) {
   
   output$Gráfica <- renderPlot({
     ggplot(mpg) + 
       geom_point(aes(x=cty, y=hwy))
   })
   output$hover <- renderTable({
     nearPoints(mpg, input$clickGráfica)
   })
   output$click <- renderTable({
     nearPoints(mpg, input$clickGráfica1)
   })
   output$dblclick <- renderTable({
     nearPoints(mpg, input$clickGráfica2)
   })
})


# Run the application 
shinyApp(ui = ui, server = server)

