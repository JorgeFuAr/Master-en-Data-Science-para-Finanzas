library(shiny)
library(MASS)
library(ggplot2)

# Define UI for application that draws a histogram
ui <- fluidPage(

   titlePanel("Generar muestras aleatorias"),
   
   sidebarLayout(
      sidebarPanel(
        numericInput("n", "Tamaño muestral", 50),
        numericInput("p", "Correlación", 0.5, step = 0.01),
        actionButton("go", "Generar muestra aleatoria")
      ),
      
      # Show a plot of the generated distribution
      mainPanel(
         plotOutput("plot", click = "click"),
         verbatimTextOutput("correlacion")
      )
   )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
   misDatos <- reactiveValues(muestra = NULL)
 
   observe({
     input$go
     cor <- isolate(as.numeric(input$p))
     sig <- matrix(c(1,cor,cor,1), 2)
     n <- isolate(as.numeric(input$n))
     misDatos$muestra <- mvrnorm(n,c(0,0),sig)
   })
   
   observeEvent(input$click,{
     misDatos$muestra <- rbind(misDatos$muestra,c(input$click$x,input$click$y))
   })
   
   output$correlacion <- renderText({
     paste0("Correlación: ", cor(misDatos$muestra)[1,2])
   })
   output$plot <- renderPlot({
     plot(misDatos$muestra, xlab = "", ylab = "")
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

