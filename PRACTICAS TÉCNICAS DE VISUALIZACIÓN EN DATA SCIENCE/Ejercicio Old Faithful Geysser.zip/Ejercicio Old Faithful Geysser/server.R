library(shiny)

shinyServer <- function(input, output) {
  
  output$plot <- renderPlot({
    
    bins <- seq(min(faithful$waiting), max(faithful$waiting), length.out = input$bins + 1)
    
    hist(faithful$waiting, breaks=bins, col="blue", border="white",  #en server es renderXXX
                                 xlab="Modelos",
                                 main="Histograma"
                                 )})          
  
}
