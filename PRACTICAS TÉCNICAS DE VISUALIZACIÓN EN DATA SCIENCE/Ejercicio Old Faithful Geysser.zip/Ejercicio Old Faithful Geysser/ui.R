library(shiny)

shinyUI(
  
  fluidPage(
    titlePanel("Old Faithful Geysser"),
    sidebarLayout(
      sidebarPanel(
        sliderInput("bins", "Number of bins", 0, 30, 15)
      ), 
      mainPanel(
        plotOutput("plot")       #En ui es XXXOutput
      )
    )
  )
  
  
)



