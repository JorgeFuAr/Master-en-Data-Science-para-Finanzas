#install.packages("plotly")
require(plotly)
library(shiny)

function(input, output) {
  output$grafica <- renderPlot({
    
    graficaBase <- ggplot(mpg,
                          aes_string(x=input$variablex,
                                     y=input$variabley)) +
      geom_point()
      
    if(input$facet){
        graficaBase + facet_wrap(~manufacturer,
                                 ncol=4)
      if (input$colorear_tipo)
        graficaBase+facet_wrap(~manufacturer,
                               ncol=4)+
        geom_point(aes(colour = class))
      else
        graficaBase + facet_wrap(~manufacturer,
                                 ncol=4)
    }
    else
      graficaBase
      if(input$colorear_tipo)
        graficaBase+geom_point(aes(colour = class))
      else
        graficaBase
  })
  
  
  output$texto <- renderText({
    
    #"Hola caracola"
    nth <- paste0(c("Este es el diagrama de dispersión de X: "),
                  input$variablex, 
                  c(" y de Y: "),
                  input$variabley)
    
  })
  
  
  
}
  