#install.packages("plotly")
require(plotly)

shinyUI(
  fluidPage(
    sidebarLayout(
      sidebarPanel(
        selectInput("variablex",
                    label = "Eje horizontal",
                    choices = c("Cylinders" = "cyl",
                                "Miles per galon" = "hwy",
                                "displacement" = "displ")),
        selectInput("variabley",
                    label = "Eje vertical",
                    choices = c("Cylinders" = "cyl",
                                "Miles per galon" = "hwy",
                                "displacement" = "displ")),
        checkboxInput("facet",
                      label = "División",
                      value = F),
        checkboxInput("colorear_tipo",
                      label = "color",
                      value = F)
        
      ),
      mainPanel(
        textOutput("texto"),
        plotOutput("grafica")
      )
    )
  )
  
)