b <- ggplot(mpg, aes(class, cty))

b + geom_boxplot(varwidth=T, fill=input$color) +
  labs(title="Box plot",
       subtitle="City Mileage grouped by Class of vehicle",
       caption="Source: mpg",
       x="Class of Vehicle",
       y="City Mileage") +
  theme_base(base_size = input$size, base_family = input$font)