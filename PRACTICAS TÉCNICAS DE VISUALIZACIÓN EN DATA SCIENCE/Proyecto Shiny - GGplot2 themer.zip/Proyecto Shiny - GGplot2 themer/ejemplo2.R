h <- ggplot(mpg, aes(displ)) + scale_fill_brewer(palette = "Spectral")

h + geom_histogram(aes(fill=class), 
                   binwidth = .1, 
                   col = input$color, 
                   size = .1) +  
  labs(title="Histogram with Auto Binning", 
       subtitle="Engine Displacement across Vehicle Classes") +
  theme_base(base_size = input$size, base_family = input$font)