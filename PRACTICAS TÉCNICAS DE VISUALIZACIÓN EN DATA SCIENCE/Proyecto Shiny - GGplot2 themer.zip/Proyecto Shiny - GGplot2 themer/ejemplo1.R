mpg_select <- mpg[mpg$hwy >= 35 & mpg$cty > 27, ]
g <- ggplot(mpg, aes(cty, hwy)) + 
  geom_count(colour = input$color) + 
  geom_smooth(method="lm", se=F) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Marginal Histogram") +
  theme_base(base_size = input$size, base_family = input$font)

ggMarginal(g, type = "histogram", fill="transparent")