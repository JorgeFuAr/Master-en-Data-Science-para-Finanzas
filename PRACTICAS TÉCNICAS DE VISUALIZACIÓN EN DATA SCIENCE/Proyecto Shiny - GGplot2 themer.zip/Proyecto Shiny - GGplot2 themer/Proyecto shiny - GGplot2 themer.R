library(shiny)
library(shinythemes)
library(shinydashboard)
library(ggplot2)
library(ggExtra)
library(ggthemes)
library(extrafont)
# install.packages("shinyBS")
library(shinyBS)
# install.packages("blogdown")
library(blogdown)
# font_import()
# loadfonts(device = "win")


leer <- function(fileName) readChar(fileName, file.info(fileName)$size)

ejemplo0 <- leer("ejemplo0.R")
ejemplo1 <- leer("ejemplo1.R")
ejemplo2 <- leer("ejemplo2.R")
ejemplo3 <- leer("ejemplo3.R")
ejemplo4 <- leer("ejemplo4.R")
ejemplo5 <- leer("ejemplo5.R")

ui <- shinyUI(
  bootstrapPage(
    dashboardPage(
      dashboardHeader(title = "GGplot2 themer"),
      dashboardSidebar(
        tags$style(".navbar {background-color: #b8baea !important}",
                   ".main-sidebar {background-color: #c1c2f5 !important}",
                   ".content-wrapper {background-color: #efd68e !important}",
                   ".logo {background-color: #b8baea !important}",
                   ".sidebar-toggle {color: #171a71 !important}",
                   ".logo {color: #171a71 !important}",
                   ".logo {font-family: Agency FB !important}"),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: right;",
            checkboxInput("box", "Shiny themes", value = FALSE)
          ),
          
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q1",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q1",
              title = "Info",
              content = "Check for change shiny themes to your liking.",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: top;",
            conditionalPanel(
              condition = "input.box == '1'",
              themeSelector()
            ),
            checkboxInput("properties", "Change properties", value = FALSE),
            conditionalPanel(
              condition = "input.properties == '1'",
              numericInput("size", "Letter size", value = 16),
              selectInput("font", "Family font", choices = fonts()),
              selectInput("color", "Graphic color", choices = c("#b8baea", colors()))
            )
          ),
          
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q2",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q2",
              title = "Info",
              content = "Check for change graphic properties to your liking: letter size, family font and graphic color. When it is finish, click run button (source code box) and look at the graphic.",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: middle;",
            radioButtons("type", "Download plot to...", choices = list(".png", ".pdf"))
          ),
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q3",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q3",
              title = "Info",
              content = "Choose type of format you want to download.",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: middle;",
            textInput("name", "File name: ")
          ),
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q4",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q4",
              title = "Info",
              content = "You can write here the name of this graphic you are going to download in .png or .pdf",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: right;",
            downloadButton("download", "Download Plot", class = "butt")
          ),
          
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q5",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q5",
              title = "Info",
              content = "Before download your design plot, click Run button in source code box.",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: middle;",
            textInput("name1", "File name (.csv):")
          ),
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q6",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q6",
              title = "Info",
              content = "You can write here the name of the dataset mpg you are going to download in .csv",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        downloadButton("download1", "Download Data", class = "butt"),
        div(
          div(
            style="width:80%; display:inline-block; vertical-align: middle;",
            textInput("name2", "File name (.R):")
          ),
          div(
            style="display:inline-block; vertical-align: middle;",
            bsButton(
              "q9",
              label = "",
              icon = icon("question"),
              style = "info",
              size = "extra-small"
            ),
            bsPopover(
              id = "q9",
              title = "Info",
              content = "You can write here the name of this source code you are going to download in .R",
              placement = "right",
              trigger = "hover",
              options = list(container = "body")
            )
          )
        ),
        downloadButton("downloadSourceCode", "Download Source Code", class = "butt"),
        tags$style(".butt{background-color:white !important}",
                   ".butt{color: darkblue !important}",
                   ".butt{font-family: Script MT Bold !important}")
      ),
      dashboardBody(
        fluidRow(
          box(
            title = "Select graphic theme", 
            solidHeader = TRUE,
            background = "yellow",
            status = "warning",
            width = 3,
            selectInput("select", label = NULL, choices = list("Counts Plot"=0,
                                                               "Marginal Histogram"=1,
                                                               "Histogram"=2,
                                                               "Density Plot"=3, 
                                                               "Box Plot"=4, 
                                                               "Violin Plot"=5))
          ),
          box(
            width = 8,
            plotOutput("plot",
                       hover = "cursor",
                       click = "click",
                       dblclick = "dobleclick", 
                       brush = brushOpts("brush", stroke = "blue"))
          ),
          fluidRow(
            box(title = "Source code",
                solidHeader = TRUE, 
                background = "yellow",
                status = "warning",
                width = 10,
                collapsible = TRUE,
                collapsed = TRUE,
                div(
                  div(
                    style="width:80%; display:inline-block; vertical-align: top;",
                    textAreaInput("codigo", 
                                  label = NULL,
                                  value = "", 
                                  width = "700px", 
                                  height = "200px",
                                  resize = "none"),
                    
                    actionButton("run", "Run")
                  ),
                  div(
                    style="display:inline-block; vertical-align: middle;",
                    bsButton(
                      "q7",
                      label = "",
                      icon = icon("question"),
                      style = "warning",
                      size = "extra-small"
                    ),
                    bsPopover(
                      id = "q7",
                      title = "Info",
                      content = "Here you can change the source code to modify whatever you want of the graphic. When it is finish, click run button and look at the graphic.",
                      placement = "right",
                      trigger = "hover",
                      options = list(container = "body")
                    )
                  )
                )
            ),
            
            box(title = "Click events (Counts Plot, Box Plot and Violin Plot)",
                solidHeader = TRUE, 
                status = "warning",
                width = 10,
                background = "yellow",
                collapsible = TRUE,
                collapsed = TRUE,
                div(
                  div(
                    style="width:80%; display:inline-block; vertical-align: top;",
                    tabsetPanel(
                      tabPanel("Hover", tableOutput("hover")),
                      tabPanel("Click", tableOutput("click")),
                      tabPanel("Doble Click", tableOutput("dblclick")),
                      tabPanel("Brush", tableOutput("brush"))
                    )
                  ),
                  div(
                    style="display:inline-block; vertical-align: middle;",
                    bsButton(
                      "q8",
                      label = "",
                      icon = icon("question"),
                      style = "warning",
                      size = "extra-small"
                    ),
                    bsPopover(
                      id = "q8",
                      title = "Info",
                      content = "See all the information doing hover, clicking, double clicking or brushing only on the points in Counts Plot, Box Plot and Violin Plot.",
                      placement = "right",
                      trigger = "hover",
                      options = list(container = "body")
                    )
                  )
                )
                
            )
          )
          
        )
      )
    )
    
  )
)

server <-   function(input, output, session){
  
  myData <- reactiveValues(grafica = NULL)
  
  showNotification("Welcome GGplot2 themer!", duration = 7, type = "warning")
  
  observeEvent({
    input$font
    input$size
    input$color},{
      showNotification(paste0("Your choice: ",
                              input$size, 
                              "pt, ",
                              input$font, 
                              ", " ,
                              input$color), 
                       duration = 5,
                       closeButton = F,
                       type = "message")
    })
  
  theme <- reactive({
    if(input$select=="0"){
      c <- ggplot(mpg, aes(cty, hwy, size=hwy))
      
      c + geom_count(colour = input$color, show.legend=T) +
        labs(subtitle="mpg: city vs highway mileage", 
             y="hwy", 
             x="cty", 
             title="Counts Plot") +
        theme_base(base_size = input$size, base_family = input$font)
      
    } else {
      if(input$select=="1"){
        mpg_select <- mpg[mpg$hwy >= 35 & mpg$cty > 27, ]
        g <- ggplot(mpg, aes(cty, hwy)) + 
          geom_count(colour = input$color) + 
          geom_smooth(method="lm", se=F) +
          labs(subtitle="mpg: city vs highway mileage", 
               y="hwy", 
               x="cty", 
               title="Marginal Histogram") +
          theme_base(base_size = input$size, base_family = input$font)
        
        ggMarginal(g, type = "histogram", fill="transparent")
        
      } else {
        if(input$select=="2"){
          h <- ggplot(mpg, aes(displ)) + scale_fill_brewer(palette = "Spectral")
          
          h + geom_histogram(aes(fill=class), 
                             binwidth = .1, 
                             col = input$color, 
                             size = .1) +  
            labs(title="Histogram with Auto Binning", 
                 subtitle="Engine Displacement across Vehicle Classes") +
            theme_base(base_size = input$size, base_family = input$font)
          
        } else { 
          if(input$select=="3"){
            d <- ggplot(mpg, aes(cty))
            
            d + geom_density(aes(fill=factor(cyl)), colour = input$color, alpha=0.8) + 
              labs(title="Density plot", 
                   subtitle="City Mileage Grouped by Number of cylinders",
                   caption="Source: mpg",
                   x="City Mileage",
                   fill="Cylinders") +
              theme_base(base_size = input$size, base_family = input$font)
            
          } else {
            if(input$select=="4"){
              b <- ggplot(mpg, aes(class, cty))
              
              b + geom_boxplot(varwidth=T, fill=input$color) + 
                labs(title="Box plot", 
                     subtitle="City Mileage grouped by Class of vehicle",
                     caption="Source: mpg",
                     x="Class of Vehicle",
                     y="City Mileage") +
                theme_base(base_size = input$size, base_family = input$font)
              
            } else {
              if(input$select=="5"){
                g <- ggplot(mpg, aes(class, cty))
                
                g + geom_violin(fill = input$color) + 
                  labs(title="Violin plot", 
                       subtitle="City Mileage vs Class of vehicle",
                       caption="Source: mpg",
                       x="Class of Vehicle",
                       y="City Mileage") +
                  theme_base(base_size = input$size, base_family = input$font)
              }
            }
          }
        }
        
      }
      
    }
  })
  


  observeEvent({
    input$select
    input$color
    input$size
    input$font}, {
      updateTextAreaInput(session,
                          "codigo",
                          value =
                            if(input$select=="0") {
                              ejemplo0 <- gsub("input$color",
                                               paste0("'",input$color,"'"),
                                               ejemplo0,
                                               fixed = TRUE)
                              ejemplo0 <- gsub("input$size",
                                               input$size,
                                               ejemplo0,
                                               fixed = TRUE)
                              ejemplo0 <- gsub("input$font",
                                               paste0("'",input$font,"'"),
                                               ejemplo0,
                                               fixed = TRUE)
                              ejemplo0
                            } else {
                              if(input$select=="1"){
                                ejemplo1 <- gsub("input$color",
                                                 paste0("'",input$color,"'"),
                                                 ejemplo1,
                                                 fixed = TRUE)
                                ejemplo1 <- gsub("input$size",
                                                 input$size,
                                                 ejemplo1,
                                                 fixed = TRUE)
                                ejemplo1 <- gsub("input$font",
                                                 paste0("'",input$font,"'"),
                                                 ejemplo1,
                                                 fixed = TRUE)
                                ejemplo1
                              } else {
                                if(input$select=="2"){
                                  ejemplo2 <- gsub("input$color",
                                                   paste0("'",input$color,"'"),
                                                   ejemplo2,
                                                   fixed = TRUE)
                                  ejemplo2 <- gsub("input$size",
                                                   input$size,
                                                   ejemplo2,
                                                   fixed = TRUE)
                                  ejemplo2 <- gsub("input$font",
                                                   paste0("'",input$font,"'"),
                                                   ejemplo2,
                                                   fixed = TRUE)
                                  ejemplo2
                                } else { 
                                  if(input$select=="3"){
                                    ejemplo3 <- gsub("input$color",
                                                     paste0("'",input$color,"'"),
                                                     ejemplo3,
                                                     fixed = TRUE)
                                    ejemplo3 <- gsub("input$size",
                                                     input$size,
                                                     ejemplo3,
                                                     fixed = TRUE)
                                    ejemplo3 <- gsub("input$font",
                                                     paste0("'",input$font,"'"),
                                                     ejemplo3,
                                                     fixed = TRUE)
                                    ejemplo3
                                  } else {
                                    if(input$select=="4"){
                                      ejemplo4 <- gsub("input$color",
                                                       paste0("'",input$color,"'"),
                                                       ejemplo4,
                                                       fixed = TRUE)
                                      ejemplo4 <- gsub("input$size",
                                                       input$size,
                                                       ejemplo4,
                                                       fixed = TRUE)
                                      ejemplo4 <- gsub("input$font",
                                                       paste0("'",input$font,"'"),
                                                       ejemplo4,
                                                       fixed = TRUE)
                                      ejemplo4
                                    } else {
                                      if(input$select=="5"){
                                        ejemplo5 <- gsub("input$color",
                                                         paste0("'",input$color,"'"),
                                                         ejemplo5,
                                                         fixed = TRUE)
                                        ejemplo5 <- gsub("input$size",
                                                         input$size,
                                                         ejemplo5,
                                                         fixed = TRUE)
                                        ejemplo5 <- gsub("input$font",
                                                         paste0("'",input$font,"'"),
                                                         ejemplo5,
                                                         fixed = TRUE)
                                        ejemplo5
                                      }
                                    }
                                  }
                                }
                                
                              }
                              
                            })
    })
  
  observeEvent(input$run, {
    myData$grafica <- eval(parse(text = input$codigo))
    output$plot <- renderPlot({
      myData$grafica
    })
  })
  
  # observeEvent: eval(parse(text="1+1+a"))
  output$plot <- renderPlot({
    theme()
  })
  
  plotInput <- reactive({
    p <- myData$grafica
  })

  output$download <- downloadHandler(
    filename = function() { paste(input$name, input$type, sep='.') },
    content = function(file) {
      ggsave(file,plotInput())
    }
  )
  output$download1 <- downloadHandler(
    filename = function() { paste(input$name1, 'csv', sep='.') },
    content = function(file) {
      write.csv(mpg, file)
    }
  )
  
  output$downloadSourceCode <- downloadHandler(
    filename = function() { paste(input$name2, 'R', sep='.')},
    content = function(file) {
      writeChar(input$codigo,file)
    }
  )
 
  output$hover <- renderTable({
    nearPoints(mpg, input$cursor)
  })
  output$click <- renderTable({
    nearPoints(mpg, input$click)
  })
  output$dblclick <- renderTable({
    nearPoints(mpg, input$dobleclick)
  })
  output$brush <- renderTable({
    brushedPoints(mpg, input$brush)
  })
}


shinyApp(ui = ui, server = server)
