g <- ggplot(mpg, aes(class, cty))

g + geom_violin(fill = input$color) + 
  labs(title="Violin plot", 
       subtitle="City Mileage vs Class of vehicle",
       caption="Source: mpg",
       x="Class of Vehicle",
       y="City Mileage") +
  theme_base(base_size = input$size, base_family = input$font)