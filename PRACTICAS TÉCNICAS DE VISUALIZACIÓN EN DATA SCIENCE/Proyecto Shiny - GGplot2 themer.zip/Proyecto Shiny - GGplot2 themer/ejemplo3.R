d <- ggplot(mpg, aes(cty))

d + geom_density(aes(fill=factor(cyl)), colour = input$color, alpha=0.8) + 
  labs(title="Density plot", 
       subtitle="City Mileage Grouped by Number of cylinders",
       caption="Source: mpg",
       x="City Mileage",
       fill="Cylinders") +
  theme_base(base_size = input$size, base_family = input$font)