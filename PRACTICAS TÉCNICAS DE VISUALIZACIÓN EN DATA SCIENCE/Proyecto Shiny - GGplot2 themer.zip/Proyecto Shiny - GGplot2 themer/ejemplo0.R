c <- ggplot(mpg, aes(cty, hwy, size=hwy))

c + geom_count(colour = input$color, show.legend=T) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Counts Plot") +
  theme_base(base_size = input$size, base_family = input$font)