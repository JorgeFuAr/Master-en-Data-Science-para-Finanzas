

ui <- shinyUI(
  pageWithSidebar(
    headerPanel('Downloading Data'),
    sidebarPanel(
      selectInput("dataset", "Choose a dataset:", 
                  choices = c("rock", "pressure", "cars")),
      downloadButton('downloadData', 'Download Data'),
      downloadButton('downloadPlot', 'Download Plot')
    ),
    mainPanel(
      plotOutput('plot')
    )
  )
)

server <- function(input, output) {
  
  datasetInput <- reactive({
    switch(input$dataset,
           "rock" = rock,
           "pressure" = pressure,
           "cars" = cars)
  })
  
  plotInput <- reactive({
    df <- datasetInput()
    p <-ggplot(df, aes_string(x=names(df)[1], y=names(df)[2])) +
      geom_point()
  })
  
  output$download1 <- downloadHandler(
    filename = function() { paste(input$name1, '.csv', sep='') },
    content = function(con) {
      write.csv(data, con)
    }
  )
}


shinyApp(ui, server)