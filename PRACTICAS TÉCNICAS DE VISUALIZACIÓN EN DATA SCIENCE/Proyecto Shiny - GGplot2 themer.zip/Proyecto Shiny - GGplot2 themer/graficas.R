myData$grafica <- 
  if(input$select=="0"){
    c <- ggplot(mpg, aes(cty, hwy, size=hwy))
    
    c + geom_count(colour = input$color, show.legend=T) +
      labs(subtitle="mpg: city vs highway mileage", 
           y="hwy", 
           x="cty", 
           title="Counts Plot") +
      theme_base(base_size = input$size, base_family = input$font)
    
  } else {
    if(input$select=="1"){
      mpg_select <- mpg[mpg$hwy >= 35 & mpg$cty > 27, ]
      g <- ggplot(mpg, aes(cty, hwy)) + 
        geom_count(colour = input$color) + 
        geom_smooth(method="lm", se=F) +
        labs(subtitle="mpg: city vs highway mileage", 
             y="hwy", 
             x="cty", 
             title="Marginal Histogram") +
        theme_base(base_size = input$size, base_family = input$font)
      
      ggMarginal(g, type = "histogram", fill="transparent")
      
    } else {
      if(input$select=="2"){
        h <- ggplot(mpg, aes(displ)) + scale_fill_brewer(palette = "Spectral")
        
        h + geom_histogram(aes(fill=class), 
                           binwidth = .1, 
                           col = input$color, 
                           size = .1) +  
          labs(title="Histogram with Auto Binning", 
               subtitle="Engine Displacement across Vehicle Classes") +
          theme_base(base_size = input$size, base_family = input$font)
        
      } else { 
        if(input$select=="3"){
          d <- ggplot(mpg, aes(cty))
          
          d + geom_density(aes(fill=factor(cyl)), colour = input$color, alpha=0.8) + 
            labs(title="Density plot", 
                 subtitle="City Mileage Grouped by Number of cylinders",
                 caption="Source: mpg",
                 x="City Mileage",
                 fill="Cylinders") +
            theme_base(base_size = input$size, base_family = input$font)
          
        } else {
          if(input$select=="4"){
            b <- ggplot(mpg, aes(class, cty))
            
            b + geom_boxplot(varwidth=T, fill=input$color) + 
              labs(title="Box plot", 
                   subtitle="City Mileage grouped by Class of vehicle",
                   caption="Source: mpg",
                   x="Class of Vehicle",
                   y="City Mileage") +
              theme_base(base_size = input$size, base_family = input$font)
            
          } else {
            if(input$select=="5"){
              g <- ggplot(mpg, aes(class, cty))
              
              g + geom_violin(fill = input$color) + 
                labs(title="Violin plot", 
                     subtitle="City Mileage vs Class of vehicle",
                     caption="Source: mpg",
                     x="Class of Vehicle",
                     y="City Mileage") +
                theme_base(base_size = input$size, base_family = input$font)
            }
          }
        }
      }
      
    }
    
  }