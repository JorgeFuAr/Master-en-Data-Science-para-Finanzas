# install.packages("shiny")
library(shiny)
# install.packages("ggplot2")
library(ggplot2)
# install.packages("shinydashboard")
library(shinydashboard)
# install.packages("miscor")
library(miscor)

ui <- shinyUI( 
  fluidPage(
    # Realizamos la grafica que posteriormente se visualizará indicando diferentes eventos: click, doble click, hover y brush.
    plotOutput("plot",
               click = "click",
               dblclick = "dobleclick",
               hover = "hover",
               brush = "brush"
    ),
    # En el verbatimTextOutput haremos que se visualice la media de los puntos que se han marcado con brush
    verbatimTextOutput("brush"),
    # Con estas dos tablas creadas, haremos que nos muestre las coordenadas del punto cercano mediante un click (primer tabla)
    # y pasando el ratón por encima, es decir, mediante un hover (segunda tabla)
    tableOutput("click"),
    tableOutput("hover")
  )
)

server <- function(input, output) {
  
  # Creamos una distribución bivariada con la función sim.cor, que simula esta distribución con una muestra
  # de 20 puntos (por eso ponemos 20) y una correlación de 0.
  distribucion <- sim.cor(20,0)
  
  # Se visualiza la gráfica de puntos 
  output$plot <- renderPlot({
    ggplot(distribucion, aes(x=x, y=y)) + 
      geom_point()
  })
  # Tabla para ver las coordenadas de los puntos cercanos mediante un click
  output$click <- renderTable({
    nearPoints(distribucion, input$click)
  })
  # Tabla para ver las coordenadas de los puntos cercanos mediante un hover
  output$hover <- renderTable({
    nearPoints(distribucion, input$hover)
  })
  # verbatimTextOutput para que poder ver la media de los puntos seleccionados.
  output$brush <- renderText({
    puntos = brushedPoints(distribucion, input$brush)
    paste0("La media de los puntos seleccionados es: ", mean(as.matrix(puntos)))
  })
  
}

shinyApp(ui = ui, server = server)