### Extracción de entidades

# Por último vamos a extraer entidades. Inicializamos ls anotadores. Necesitamos anotar con sentencias y palabras antes de extraer entidades.

# En primer lugar vamos a crear el texto a analizar y lo metemos en una cadena de caracteres. Utilizaré una cadena fija, porque controlamos lo que se debe extraer. Para los documentos del corpus, la cadena a extraer en cada documento sería, por ejemplo para el primer documento del corpus "clase 1" docs_cl1[1]$content

txt_analizar <- "El temor a lo que ellos mismos llaman ‘hacer un Escolano’ se extiende entre los
ministrables y posibles segundos escalones económicos que trabajan en el
sector privado o en cargos con más futuro que el corto plazo que les puede
ofrecer Pedro Sánchez para entrar en el Gobierno. ¿Qué es hacer un Escolano?
Lo que le ha pasado al ministro saliente de Economía, Román Escolano, que
personifica un gran ejemplo de sacrificio económico y profesional por el
servicio público. Renunció a sus 300.000 euros anuales de vicepresidente del
Banco Europeo de Inversiones (BEI) el pasado marzo por los 70.000 de
ministro. Y, según la Ley de Conflictos de Interés de altos cargos endurecida en
2006 por el entonces ministro socialista Jordi Sevilla, basta haber dirigido unos
días un Ministerio para esta obligación: ‘Los altos cargos, durante los dos años
siguientes a la fecha de su cese, no podrán prestar servicios en entidades
privadas que hayan resultado afectadas por decisiones en las que hayan
participado’. Escolano, que ha sido ministro de Economía, Industria y
Competitividad, no puede trabajar teóricamente en prácticamente ningún sector
hasta junio de 2020 tras solo ¡tres meses! en el cargo. El experimentado
ministro saliente es técnico comercial del Estado y no queda en el paro, pero su
carrera habría ido mejor si hubiera seguido en el BEI."


# Convertimos a string y comprobamos su valor:

str_analizar <- as.String(txt_analizar)
str_analizar


# Inicializamos los anotadores: el de sentencias, el de palabras, y el de entidades. Para extraer entidades es necesario haber hecho previamente las siguientes anotaciones:
sent_token_annotator <- Maxent_Sent_Token_Annotator() # anotador de frases
word_token_annotator <- Maxent_Word_Token_Annotator() # anotador de palabras

entity_loc_annotator <- Maxent_Entity_Annotator(language = "es", kind = "location", probs = FALSE, model = NULL)
entity_org_annotator <- Maxent_Entity_Annotator(language = "es", kind = "organization", probs = FALSE, model = NULL)
entity_per_annotator <- Maxent_Entity_Annotator(language = "es", kind = "person", probs = FALSE, model = NULL)


# Y anotamos str_analizar con los anotadores, uno detrás de otro:

str_anotada <- annotate(str_analizar, list(sent_token_annotator, word_token_annotator))

annotated_org_val <- annotate(str_analizar, list(entity_loc_annotator, entity_org_annotator, entity_per_annotator), str_anotada)


# Mostramos los resultados obtenidos:

annotated_org_val

str_analizar[annotated_org_val]








