### Resumen ejecutivo

# Para la parte práctica del examen, vamos a realizar un script donde llevaremos a cabo una serie de 
# ejercicios de text mining. Tenemos documentos en formato .txt que se tratan de noticias de prensa 
# extraídas en dos subdirectorios y previamente clasificadas.

### Instalamos y cargamos las librerías necesarias

library(rJava)
library(NLP)
library(openNLP)
library(openNLPmodels.en)
library(openNLPmodels.es)
library(tm)
library(textcat)
library(wordcloud)
library(topicmodels)
library(tidytext)
library(stringr)
library(tidyr)
library(ggplot2)
library(plyr)
library(dplyr)
library(SnowballC)
library(RTextTools)
library(caret)
library(lattice)
# install.packages("arm")
library(arm)
library(class)


### Cargamos los datos (Primera pregunta)

# Disponemos de dos grupos de documentos en formatos txt (Deportes y economía). Ya están clasificados en dos subdirectorios diferentes. Vamos a crear en primer lugar un corpus para todos los documentos txt, otro para los de deportes solo y un último para los referidos a noticias económicas.


docs<- Corpus(DirSource(directory = "C:/Users/argue/Desktop/MASTER/SEGUNDO CUATRIMESTRE/GESTIÓN DE INFORMACIÓN NO ESTRUCTURADA/Examen 2018/documentos/", recursive=TRUE))
docs_deportes<- Corpus(DirSource(directory = "C:/Users/argue/Desktop/MASTER/SEGUNDO CUATRIMESTRE/GESTIÓN DE INFORMACIÓN NO ESTRUCTURADA/Examen 2018/documentos/Deportes", recursive=TRUE)) 
docs_economia <- Corpus(DirSource(directory = "C:/Users/argue/Desktop/MASTER/SEGUNDO CUATRIMESTRE/GESTIÓN DE INFORMACIÓN NO ESTRUCTURADA/Examen 2018/documentos/Economia", recursive=TRUE))


### Pre-procesamiento y limpieza del corpus (Primera pregunta).

# En segundo lugar, vamos a llevar a cabo el preprocesamiento de los datos:
#   
# 1- tolower: Ponemos en minúsculas las palabras.
# 2- removePunctuation: Quitamos todos los signos de puntuación que existan.
# 3- stripWhitespace: elimina los espacios en blanco adicionales.
# 4- removeWord: elimina palabras, en este caso utilizando los stopwords para español.
# 5- removeNumbers: elimina los números.

# Por último, creamos la matriz documentos/términos y términos/documentos para el set completo.

docs <- tm_map (docs, content_transformer(tolower))
docs <- tm_map (docs,content_transformer (removePunctuation))
docs <- tm_map (docs, content_transformer(stripWhitespace))
docs <- tm_map(docs, content_transformer(removeWords), stopwords("spanish"))
docs <-tm_map(docs, content_transformer(removeNumbers))

tdm <- TermDocumentMatrix(docs) #
dtm <- DocumentTermMatrix(docs)


# Vamos a listar los idiomas de los documentos del corpus una vez realizado el pre-procesamiento:

my.profiles <- TC_byte_profiles[names(TC_byte_profiles)]
textcat(docs, p = my.profiles)


# Podemos observar como 29 documentos de los que disponemos estan en idioma castellano, siendo uno, el número 12 en idioma "rumantsch"

### Términos más frecuentes y nube de palabras. (Segunda pregunta)

# Ahora utilizaremos las matriz tdm para sacar los términos más frecuentes y obtener una nube de palabras:

m <- as.matrix(tdm)
v <- sort(rowSums(m), decreasing = TRUE)
d <- data.frame(word = names(v),freq = v)


# Vamos a visualizar los 30 primeros términos más frecuentes que hemos ordenado anteriormente con la frecuencia que les corresponde a cada uno:

head(d, 30)


# Obtenemos la nube de palabras de nuestro corpus con 50 documentos:

wordcloud(words = d$word, freq = d$freq, min.freq = 1,
          max.words = 50, random.order = FALSE, rot.per = 0.35, 
          colors = brewer.pal(8, "Dark2"))


### Clasificación de los documentos. (Tercera pregunta)

# Vamos a utilizar este conjunto de documentos para realizar una clasificacion y ver resultados utilizando "RTextTools". La clave consite en generar un contenedor, para luego utilizarlo con diferentes algoritmos de clasificación.

# Necesitaremos Una matriz dtm - documentos/términos (NO tmd - términos/documentos) y un vector con igual número de filas, en que aparezca por cada documento, su categoría.

# Ya tenemos la matriz dtm del conjunto completo. Vamos a generar dos data frame y poner la columna "name" con la categoría:

deportes_DF<-data.frame(text = unlist(sapply(docs_deportes, `[`,"content")), stringsAsFactors=F)
deportes.df <- cbind(deportes_DF , rep("Deportes" ,nrow(deportes_DF)))
colnames(deportes.df)[ncol(deportes.df)] <- "name"

economia_DF<-data.frame(text=unlist(sapply(docs_economia, `[`,"content")), stringsAsFactors=F)
economia.df <- cbind(economia_DF , rep("Economia" ,nrow(economia_DF)))
colnames(economia.df)[ncol(economia.df)] <- "name"

# Combinamos en un solo data frame y obtenems el vector de categorías: completo.df$name

completo.df <- rbind(deportes.df, economia.df)


# Como el contenedor necesitas las categorías como numéricas, lo factorizamos, 
# con as.numeric(factor(completo.df$name):
                                            
container <- create_container(dtm, as.numeric(factor(completo.df$name)), 
                              trainSize=1:19,
                              testSize=19:30,
                              virgin=FALSE)

#### Utilizamos modelos de clasificación de documentos con RTextTools.

# Sólo categorizaremos con SVM y MAXENT. RTextTools incorpora muchos más algoritmos:

multi_models <- train_models(container, algorithms=c("SVM","MAXENT"))
multi_results <- classify_models(container, multi_models)
multi_analytics <- create_analytics(container, multi_results)



ensemble_summary <- create_ensembleSummary(multi_analytics@document_summary)
precisionRecallSummary <- create_precisionRecallSummary(container, multi_results, b_value = 1)
scoreSummary <- create_scoreSummary(container, multi_results)
recall_acc <- recall_accuracy (multi_analytics@document_summary$MANUAL_CODE,multi_analytics@document_summary$MAXENTROPY_LABEL)


# Mostramos los resultados obtenidos:

summary(multi_results)
summary(recall_acc)
summary(scoreSummary)
summary(precisionRecallSummary)
summary(multi_analytics)







                                                