# install.packages("rJava")
# install.packages("NLP")
# install.packages("openNLP")
# install.packages("openNLPmodels.en")
# install.packages("openNLPmodels.es")

library(rJava)
library(NLP)
library(openNLP)
library(openNLPmodels.en)
library(openNLPmodels.es)

### TEXTO EN CASTELLANO ###

txtC <- "Si el terremoto por el futuro del brasileño fue en el mes de agosto, todo apunta a que el caso Griezmann vivirá sus fechas claves durante las semanas previas al Mundial.
El galo quiere resolver su futuro antes de concentrarse en la cita de Rusia, el Barça no está por la labor de rehacer sus planes y el Atlético de Madrid preferiría no eternizarse en caso de necesitar un relevo."

txt_strC <- as.String(txtC)

sent_token_annotator <- Maxent_Sent_Token_Annotator()
word_token_annotator <- Maxent_Word_Token_Annotator()

annotated_strC <- annotate(txt_strC, list(sent_token_annotator, word_token_annotator))

entity_annotator_org <- Maxent_Entity_Annotator()

annotated_org_valC <- annotate(txt_strC, entity_annotator_org, annotated_strC)

annotated_org_valC
txt_strC[annotated_org_valC]


d_org_valC <- annotate(txt_strC, entity_annotator_org, annotated_strC)

annotated_org_valC
txt_strC[annotated_org_valC]

# Podemos ver que, en castellano, nuestro algoritmo ha detectado de forma perfectamente correcta que nuestro texto está compuesto por dos frases
# teniendo la primera frase un total de 33 palabras y 157 letras y caractéres (signos de puntuación), y la segunda frase un total de 36 palabras y 203 letras y caractéres.
# Identifica perfectamente desde que letra o caracter hasta que letra o caracter va cada frase y cada una de las palabras. Además, con 'txt_strC[annotated_org_valC]'
# separa perfectamente las dos frases y cada una de las palabras pertenecientes a cada frase.

### TEXTO EN INGLÉS ###

txtI <- "Until Griezmann says something we have to wait, is the word coming out of the Catalan club now, and has changed from the assumption that a move was on track. 
Their is now concern over Griezmanns reaction to being whistled at the Wanda Metropolitano and Barcelona know better than anyone how these types of moves can turn very quickly as was the case with Neymar."

txt_strI <- as.String(txtI)

annotated_strI <- annotate(txt_strI, list(sent_token_annotator, word_token_annotator))

annotated_org_valI <- annotate(txt_strI, entity_annotator_org, annotated_strI)

annotated_org_valI
txt_strI[annotated_org_valI]

d_org_valI <- annotate(txt_strI, entity_annotator_org, annotated_strI)

annotated_org_valI
txt_strI[annotated_org_valI]

# Podemos ver que, en inglés, nuestro algoritmo ha detectado de forma perfectamente correcta que nuestro texto está compuesto por dos frases
# teniendo la primera frase un total de 33 palabras y 157 letras y caractéres (signos de puntuación), y la segunda frase un total de 36 palabras y 203 letras y caractéres.
# Identifica perfectamente desde que letra o caracter hasta que letra o caracter va cada frase y cada una de las palabras. Además, con 'txt_strI[annotated_org_valI]'
# separa perfectamente las dos frases y cada una de las palabras pertenecientes a cada frase.









