install.packages("rJava")
install.packages("NLP")
install.packages("openNLP")

library(rJava)
library(NLP)
library(openNLP)

simpleText <- "Para el Dr. Ernesto G?mez, esa aproximaci?n es falsa. No se puede considerar que en U.S.A. existan medio m?s certeros"
simpleText_str <- as.String(simpleText)

sent_token_annotator <- Maxent_Sent_Token_Annotator()
annotated_sentence <- annotate(simpleText_str,sent_token_annotator)

annotated_sentence

annotated_sentence_prob <- annotate(simpleText_str, Maxent_Sent_Token_Annotator(probs = TRUE))
simpleText_str[annotated_sentence]

word_token_annotator <- Maxent_Word_Token_Annotator(probs=TRUE)
annotated_word <- annotate (simpleText_str, word_token_annotator, annotated_sentence)
simpleText_str[annotated_word]
