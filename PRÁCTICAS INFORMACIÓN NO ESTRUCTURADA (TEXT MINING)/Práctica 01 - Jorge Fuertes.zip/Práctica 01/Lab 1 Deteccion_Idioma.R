library(textcat)	# Importar el paquete e incluir la librería textcat

my.profiles <- TC_byte_profiles[names(TC_byte_profiles)]

my.profiles

my.text <- c("Im Jorge and a like to play basketball", "Jugar al baloncesto y el deporte me encantan")  # Definir un vector con varias cadenas en diferentes idiomas

textcat(my.text, p = my.profiles) # Imprimir los idiomas en los que están las cadenas anteriores
