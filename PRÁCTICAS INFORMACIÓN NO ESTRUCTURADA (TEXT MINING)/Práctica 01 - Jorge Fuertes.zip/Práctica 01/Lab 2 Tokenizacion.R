# install.packages("tm")
library(tm)

data(acq) # Importa un conjunto de datos

tdm <- TermDocumentMatrix(acq) # Genera una matriz documentos/terminos

# Ejecutar e interpretar el resultado de las siguientes funciones

Docs(tdm)
nDocs(tdm)
nTerms(tdm)
Terms(tdm)
findFreqTerms(tdm,30)


s <- "Minsait cuenta, con un catálogo de soluciones de negocio para ofrecer una respuesta integral a los retos"	#Introducir una cadena larga en español

MC_tokenizer(s)
scan_tokenizer(s)

# Interpretar las diferencias entre ambas funciones

# A primera vista, parece que la función MC_tokenizer(s) entiende todos los signos (tildes, puntuación, positivo, negativo...etc) 
# como un indicador para separar y sustituir por un "espacio", mientras que la función scan_tokenizer(s)
# entiende todos bien y separa las palabrás con los signos perfectamente colocados.
