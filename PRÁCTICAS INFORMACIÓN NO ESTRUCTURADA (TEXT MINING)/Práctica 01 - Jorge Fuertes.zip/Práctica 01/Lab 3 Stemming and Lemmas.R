# Requiere el paquete RWeka)


# install.packages("RWeka")
library(RWeka)

# Definir una variable con una cadena de palabras y llamar a las dos funciones del Stemming ¿Qué diferencia se obtiene?

IteratedLovinsStemmer(x = "Im walking down the street", control = NULL)
LovinsStemmer(x= "Im walking down the street", control = NULL)
